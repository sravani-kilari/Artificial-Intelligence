% Substring
substring(String, Start, Length, Substring) :-
    sub_string(String, Start, Length, _, Substring).

% String position
string_position(String, Substring, Position) :-
    sub_string(String, Position, _, _, Substring).

% Palindrome
is_palindrome(String) :-
    reverse(String, String).

% Union
union(Set1, Set2, Union) :-
    append(Set1, Set2, Combined),
    list_to_set(Combined, Union).

% Intersection
intersection(Set1, Set2, Intersection) :-
    findall(X, (member(X, Set1), member(X, Set2)), Intersection).

% Complement
complement(Universe, Set, Complement) :-
    subtract(Universe, Set, Complement).
