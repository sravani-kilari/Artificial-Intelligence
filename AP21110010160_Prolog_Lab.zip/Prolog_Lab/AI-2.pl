% Predicate to calculate the percentage of a student
calculate_percentage(ObtainedMarks, MaxMarks, Percentage) :-
    Percentage is (ObtainedMarks / MaxMarks) * 100.

% Predicate to display the student result
display_result(Name, RollNo, Subject, MaxMarks, ObtainedMarks) :-
    calculate_percentage(ObtainedMarks, MaxMarks, Percentage),
    format('Student Name: ~w~n', [Name]),
    format('Roll Number: ~w~n', [RollNo]),
    format('Subject: ~w~n', [Subject]),
    format('Max Marks: ~w~n', [MaxMarks]),
    format('Obtained Marks: ~w~n', [ObtainedMarks]),
    format('Percentage: ~2f%~n', [Percentage]),
    write('Result: '),
    (Percentage >= 40 -> writeln('Pass'); writeln('Fail')).

% Predicate to calculate dearness allowance (DA)
calculate_da(BasicSalary, DA) :-
    DA is 0.15 * BasicSalary.

% Predicate to calculate gross salary
calculate_gross_salary(BasicSalary, HRA, DA, GrossSalary) :-
    GrossSalary is BasicSalary + HRA + DA.

% Predicate to display employee information and pay-slip
display_pay_slip(Department, Designation, Name, Age, BasicSalary, HRA) :-
    calculate_da(BasicSalary, DA),
    calculate_gross_salary(BasicSalary, HRA, DA, GrossSalary),
    format('Department: ~w~n', [Department]),
    format('Designation: ~w~n', [Designation]),
    format('Name: ~w~n', [Name]),
    format('Age: ~w~n', [Age]),
    format('Basic Salary: $~w~n', [BasicSalary]),
    format('HRA: $~w~n', [HRA]),
    format('DA: $~2f~n', [DA]),
    format('Gross Salary: $~w~n', [GrossSalary]).

