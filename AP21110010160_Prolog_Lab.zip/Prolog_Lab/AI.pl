%Rules
parent(john, sarah).
parent(john, jim).
parent(sarah, emily).
parent(sarah, david).
parent(jim, ann).
parent(jim, peter).
parent(ann, lisa).
parent(ann, michael).
male(john).
male(jim).
male(david).
male(peter).
male(michael).
female(sarah).
female(ann).
female(lisa).
female(emily).
%Rules
mother(M,P):-parent(M, P),female(M).
father(F,P):-parent(F, P),male(F).
sibling(X,Y):-parent(Z,X),parent(Z,Y).
grandparent(X,Y):-parent(X,Z),parent(Z,Y).
sister(X,Y):-sibling(X,Y),female(X).
brother(X,Y):-sibling(X,Y),male(X).
uncle(X,Y):-parent(Z,Y),sibling(X,Z),male(X).
aunty(X,Y):-parent(Z,Y),sibling(X,Z),female(X).




